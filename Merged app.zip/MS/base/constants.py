from django.db import models


class DeviceTypes(models.TextChoices):
    LAPTOP = 'Laptop'
    MOBILE_DEVICE = 'Mobile Device'
    NON_PORTABLE_PC = 'Non portable PC'
    STANDALONE_HEADSET = 'Standalone Headset'



class ApprovalStatus(models.TextChoices):
    APPROVED = 'Approved'
    REJECTED = 'Rejected'
    NO_RESPONSE = 'No Response'



class EquipmentStatus(models.TextChoices):
    GOOD = 'Good'
    BAD = 'Bad'