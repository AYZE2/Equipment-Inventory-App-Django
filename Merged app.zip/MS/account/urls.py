from django.urls import path
from account import views


urlpatterns = [
    path('register/', views.create_user, name='register'),
    # path('home', views.home_view, name='home'),
    path('', views.user_login, name='login'),
    path('logout/', views.logout_view, name='logout'),

]