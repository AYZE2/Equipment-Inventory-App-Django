from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin

from  base.managers import UserManager
from base.model import BaseModel
# Create your models here.


class CustomUser(BaseModel, AbstractBaseUser, PermissionsMixin):
    first_name = models.CharField(max_length=225)
    last_name = models.CharField(max_length=225)
    address = models.CharField(max_length=500, null=True, blank=True)
    email = models.EmailField(unique=True)
    phone_number = models.CharField(max_length=30, null=True, blank=True)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)


    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []
    objects = UserManager()
    class Meta:
        indexes = [
            models.Index(fields=['email'])
            ]
       
    def __str__(self):
        return self.email