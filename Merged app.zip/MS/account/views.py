from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from account.forms import CustomUserForm, UserLoginForm, CustomUserUpdateForm
from django.contrib.auth import authenticate, login
from account.models import CustomUser
from equipment.models import Equipment
from django.contrib import messages
from django.contrib.auth import logout
from django.shortcuts import redirect
from django.contrib import messages
from functools import wraps
from django.contrib.auth.decorators import login_required



# This function handles user registration. It displays a registration form
# to create a new user account. If the form is submitted via POST request
# with valid data, it creates a new user object and saves it to the database.
# If the form data is invalid, it displays error messages. GET requests are
# used to display the registration form, while POST requests are used to
# process the form submission.
def create_user(request):
    if request.method == 'POST':
        form = CustomUserForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            messages.info(request, 'Login succesful')
            return redirect('login')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"Error in field '{field}': {error}")
    else:
        form = CustomUserForm()
    return render(request, 'page-register.html', {'form': form})


# This function allows a logged-in user to update their profile information.
# It retrieves the user object with the specified user_id from the database.
# If the request method is POST, it processes the form data to update the user
# object. If the form data is valid, it saves the updated user object to the
# database and redirects to the users list page. If the form data is invalid,
# it displays error messages. GET requests display the user update form.
@login_required
def update_user(request, user_id):
    user = get_object_or_404(CustomUser, pk=user_id)
    
    if request.method == 'POST':
        form = CustomUserUpdateForm(request.POST, instance=user)
        if form.is_valid():
            user = form.save()
            messages.info(request, 'User Updated Successfully')
            return redirect('users_list') 
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"Error in field '{field}': {error}")
    else:
        form = CustomUserUpdateForm(instance=user)
    
    return render(request, 'users.html', {'form': form})


# This function handles user login. It checks if the request method is POST,
# indicating a form submission. If the form data is valid, it attempts to
# authenticate the user using the provided email and password. If authentication
# is successful, the user is logged in, a success message is added to the request
# object, and the user is redirected to the device list page. If authentication
# fails, error messages are displayed. GET requests display the login form.
def user_login(request):
    if request.method == 'POST':
        form = UserLoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            user = authenticate(request, email=email, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, 'Login Successful')
                return redirect('device_list')
            else:
                for field, errors in form.errors.items():
                    for error in errors:
                        messages.error(request, f"Error in field '{field}': {error}")
    else:
        form = UserLoginForm()
    return render(request, 'page-login.html', {'form': form})


# This function logs out the currently authenticated user. It first logs out the user,
# then adds a message confirming successful logout. Finally, it redirects the user to
# the login page.
@login_required
def logout_view(request):
    logout(request)
    messages.info(request, "You have been logged out successfully.")
    return redirect('login')
