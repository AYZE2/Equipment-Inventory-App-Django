from django import forms
from .models import Equipment

class EquipmentForm(forms.ModelForm):
    class Meta:
        model = Equipment
        fields = [
            'name', 
            'type', 
            'serial_number', 
            'cpu', 
            'gpu', 
            'ram', 
    
        ]
        widgets = {
        'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter device name'}),
        'type': forms.Select(attrs={'class': 'form-control', 'placeholder': 'Select device type'}),
        'serial_number': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Serial Number'}),
        'cpu': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'cpu'}),
        'gpu': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'gpu'}),
        'ram': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'ram'}),
    }
        
