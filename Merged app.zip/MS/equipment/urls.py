from django.urls import path
from equipment import views


urlpatterns = [
    path('add_device', views.create_device, name='add_device'),
    path('device_list', views.device_list, name='device_list'),
    path('<int:device_id>/update_device', views.update_device, name='update_device_sn'),
    path('<int:device_id>/detail', views.device_detail, name='device_detail')
]