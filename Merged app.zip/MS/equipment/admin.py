from django.contrib import admin
from equipment.models import Equipment

# Register your models here.

class EquipmentAdmin(admin.ModelAdmin):
    list_display = (
        'name',
        'type',
        'serial_number',
        'cpu',
        'gpu',
        'ram'
    )


admin.site.register(Equipment, EquipmentAdmin)