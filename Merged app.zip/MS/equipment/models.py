from django.db import models

from base.constants import DeviceTypes
from base.model import BaseModel

# Create your models here.


class Equipment(BaseModel):
    name = models.CharField(max_length=225)
    type = models.CharField(max_length=20, choices=DeviceTypes.choices)
    serial_number = models.CharField(max_length=200,null=True, blank=True)
    cpu = models.CharField(max_length=1000, null=True, blank=True)
    gpu = models.CharField(max_length=225,  null=True, blank=True)
    ram = models.CharField(max_length=30,null=True, blank=True)
    def __str__(self):
        return self.name




