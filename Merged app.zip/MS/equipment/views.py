from django.shortcuts import render, redirect, get_object_or_404
from equipment.models import Equipment
from .forms import EquipmentForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required



# This function allows a logged-in user to create a new device. It handles
# both GET and POST requests. GET requests display the device creation form,
# while POST requests process the submitted form data. If the form data is
# valid, a new device is created and added to the database. A success message
# is added to the request object, and the user is redirected to the device
# list page. If the form data is invalid, error messages are displayed.
@login_required
def create_device(request):
    if request.method == 'POST':
        form = EquipmentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.info(request, 'Device added successfully')
            return redirect('device_list')
        
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"Error in field '{field}': {error}")
    else:
        form = EquipmentForm()
    return render(request, 'device.html', {'form': form})


# This function allows a logged-in user to update an existing device. It retrieves
# the device object with the specified device_id from the database. If the request
# method is POST, indicating form submission, it processes the form data to update
# the device object. If the form data is valid, the device is updated in the
# database, a success message is added to the request object, and the user is
# redirected to the device list page. If the form data is invalid, error messages
# are displayed. GET requests display the device update form pre-filled with
# existing device information.
@login_required
def update_device(request, device_id):
    device = get_object_or_404(Equipment, pk=device_id)
    
    if request.method == 'POST':
        form = EquipmentForm(request.POST, instance=device)
        if form.is_valid():
            form.save()
            messages.info(request, "Device updated successfully")
            return redirect('device_list')
        
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"Error in field '{field}': {error}")
    else:
        form = EquipmentForm(instance=device)
    
    return render(request, 'device.html', {'form': form})


# This function displays a list of devices to a logged-in user. It retrieves
# all device objects from the database and passes them to the device_list.html
# template for rendering. The template will display the list of devices.
@login_required
def device_list(request):
    devices = Equipment.objects.all()
    return render(request, 'device_list.html', {'devices': devices})


# This function displays details of a specific device to a logged-in user.
# It retrieves the device object with the specified device_id from the database
# and passes it to the device_details.html template for rendering. The template
# will display the details of the device.
@login_required
def device_detail(request, device_id):
    device = get_object_or_404(Equipment, id=device_id)

    return render(request, 'device_details.html', {'device': device})




